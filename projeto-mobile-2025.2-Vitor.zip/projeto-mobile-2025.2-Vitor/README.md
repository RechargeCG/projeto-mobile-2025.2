# projeto-mobile-2025.2
Repositório do projeto Sistema para Publicação e Leitura de Quadrinhos, desenvolvido para disciplina de Programação para Dispositivos Móveis do CEFET-MG Campus Leopoldina em 2025.2. 
