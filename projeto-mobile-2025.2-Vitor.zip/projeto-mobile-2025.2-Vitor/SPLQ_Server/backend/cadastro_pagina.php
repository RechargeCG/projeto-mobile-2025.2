<!-- Página descartada -->

<html>
    <form method="POST" action="cadastro.php">
        <input name="nome" type="text">
        <input name="email" type="text">
        <input name="senha" type="text">
        <input type="submit" value="Cadastrar">
    </form>
</html>
